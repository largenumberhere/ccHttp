A simple server that fetches all files inside of ./luaFiles 

setup a computercraft computer:
:   lua
:   load(http.get("http://localhost:8000/init.lua").readAll())()
:   exit()

run this to download any changes:
:   refresh.lua
